<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Custom_lib
{

	public $data;

	public function __construct()
	{

		$CI =& get_instance();

		$CI->load->library('form_validation');

		$CI->load->helper('html');

		$CI->load->helper('date');

		$CI->load->model('Auth_model');

	}

	public function is_login()
	{



	}

	public function is_admin()
	{



	}

	public function error_message($message){

		$element  = '<div class="alert alert-danger alert-dismissible"><h5>';
		$element .= '<i class="icon fa fa-ban"></i> Something Happened !</h5><h6>';
		$element .= $message;
		$element .= '</h6></div>';

		return $element;

	}

	public function success_message($message){

		$element  = '<div class="alert alert-success alert-section"><h5>';
		$element .= '<i class="icon fa fa-check"></i>';
		$element .= $message;
		$element .= '</h5></div>';

		return $element;

	}

	public function message_note($message = FALSE,$param = NULL,$image_size = ''){
		
		if($message = TRUE && is_array($param) && !empty($param)){

			$message = array(

				'required_input',
				'image_show',
				'image_size',
				'add_more'

				);

			$element  = '<div class="alert alert-warning">';
			$element .= '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
			$element .= '<h5>Attention!</h5>';

			foreach($param as $index => $value){

				if(in_array($value,$message)){

					if($value == 'required_input'){

						$element .= '- All input is required except publish (optional).<br>';

					}

					if($value == 'image_show'){

						$element .= '- If Your Image is not show, please to remove or compress and resize then re-upload it.<br>';

					}

					if($value == 'image_size' && !empty($image_size)){

						$element .= '- For best quality image resize it into : '.$image_size.'.<br>';

					}

					if($value == 'add_more'){

						$element .= '- If you not use form after click add more, please click remove or it will be read as required form.<br>';

					}


				} 

			}

			$element .= '</div>';

			return $element;

		}

	}

	public function filter_function_more_form($post = array()){

		$CI =& get_instance();

		$empty_key = array();

		foreach($post as $index => $value){

			foreach($value as $key => $row){

				if(empty($row)){

					$empty_key[$key] = $key;

					unset($post[$index][$key]);

				}

			}

		}

		foreach($post as $index => $value){

			foreach($value as $key => $row){

				if(in_array(array_keys($empty_key),array_keys($value)) != $key){

					unset($post[$index][$key]);

				}

			}

		}

		$field_required = array();

		foreach($post as $index => $value){

			$count_values = array_count_values($value);

			if(empty($count_values)){

				$field_required[] = $index;

			}

		}

		if(is_array($field_required) && !empty($field_required)){

			foreach($field_required as $index => $value){

				$message[] = 'The '.ucfirst($value).' field is required';

			}

			return $CI->session->set_flashdata('message',$message);

		} else {

			return $post;

		}

	}

	public function ajax_element_single_action_table($selector = '',$controller = ''){

		if(isset($selector) && isset($controller)){

			$element  = "$('".$selector."').on('click',function(){";

			$element .= "var id = $(this).parent().parent().attr('id');";

			$element .= "if(confirm('Are you sure to update your data?')){";

			$element .= "$.ajax({";

			$element .= "url: '".base_url().$controller."',";

			$element .= "type: 'POST',";

			$element .= "dataType: 'json',";

			$element .= "data: { id: id },";

			$element .= "beforeSend: function(){";

			$element .= "$('.overlay').show();";

			$element .= "},";

			$element .= "success: function(result){";

			$element .= "alert('Update Success, Redirecting..');";

			$element .= "$('.overlay').hide().fadeOut('fast');";

			$element .= "setTimeout(function(){"; 

			$element .= "window.location.href = '".base_url()."' + result;";

			$element .= "}, 500);";

			$element .= "},";

			$element .= "fail: function(){";

			$element .= "$('.overlay').hide().fadeOut('fast');";

			$element .= "alert('Something Wrong, Please Try Again');";

			$element .= "}";

			$element .= "})";

			$element .= "} else {";

			$element .= "return false;";

			$element .= "}";

			$element .= "});";

			return $element;

		} else {

			return false;
		}

	}

	public function ajax_element_published($selector = '',$selector_select = '',$controller = ''){

		if(isset($selector) && isset($selector_select) && isset($controller)){

			$element  = "$('".$selector."').on('click',function(){";

			$element .= "var checked_selected = $('".$selector_select."');";

			$element .= "var selected = [];";

			$element .= "var count_checked_length = 0;";

			$element .= "$(checked_selected).each(function(i,e){";

			$element .= "var checked = $(this).prop('checked');";

			$element .= "var checked_length = $(checked).length;";

			$element .= "count_checked_length+=checked_length;";

			$element .= "if(checked){";

			$element .= "selected.push($(this).val());";

			$element .= "}";

			$element .= "});";

			$element .= "if(count_checked_length > 0){";

			$element .= "if(confirm('Are you sure to update your item?')){";

			$element .= "$.ajax({";

			$element .= "url: '".base_url().$controller."',";

			$element .= "type: 'POST',";

			$element .= "dataType: 'json',";

			$element .= "data: { id: selected },";

			$element .= "beforeSend: function(){";

			$element .= "$('.overlay').show();";

			$element .= "},";

			$element .= "success: function(result){";

			$element .= "alert('Update Success, Redirecting..');";

			$element .= "$('.overlay').hide().fadeOut('fast');";

			$element .= "setTimeout(function(){"; 

			$element .= "window.location.href = '".base_url()."' + result;";

			$element .= "}, 500);";

			$element .= "},";

			$element .= "fail: function(){";

			$element .= "$('.overlay').hide().fadeOut('fast');";

			$element .= "alert('Something Wrong, Please Try Again');";

			$element .= "}";

			$element .= "})";

			$element .= "} else {";

			$element .= "return false;";

			$element .= "}";

			$element .= "} else {";

			$element .= "alert('You are not yet select items');";

			$element .= "return false;";

			$element .= "}";

			$element .= "});";

			return $element;

		} else {

			return false;
		}

	}

	public function ajax_element_unpublished($selector = '',$selector_select = '',$controller = ''){

		if(isset($selector) && isset($selector_select) && isset($controller)){

			$element = "$('".$selector."').on('click',function(){";

			$element .= "var checked_selected = $('".$selector_select."');";

			$element .= "var selected = [];";

			$element .= "var count_checked_length = 0;";

			$element .= "$(checked_selected).each(function(i,e){";

			$element .= "var checked = $(this).prop('checked');";

			$element .= "var checked_length = $(checked).length;";

			$element .= "count_checked_length+=checked_length;";

			$element .= "if(checked){";

			$element .= "selected.push($(this).val());";

			$element .= "}";

			$element .= "});";

			$element .= "if(count_checked_length > 0){";

			$element .= "if(confirm('Are you sure to update your item?')){";

			$element .= "$.ajax({";

			$element .= "url: '".base_url().$controller."',";
			$element .= "type: 'POST',";
			$element .= "dataType: 'json',";
			$element .= "data: { id: selected },";
			$element .= "beforeSend: function(){";

			$element .= "$('.overlay').show();";

			$element .= "},";
			$element .= "success: function(result){";

			$element .= "alert('Update Success, Redirecting..');";

			$element .= "$('.overlay').hide().fadeOut('fast');";

			$element .= "setTimeout(function(){ ";

			$element .= "window.location.href = '".base_url()."' + result;";

			$element .= "}, 500);";

			$element .= "},";
			$element .= "fail: function(){";

			$element .= "$('.overlay').hide().fadeOut('fast');";

			$element .= "alert('Something Wrong, Please Try Again');";

			$element .= "}";

			$element .= "})";

			$element .= "} else {";

			$element .= "return false;";

			$element .= "}";

			$element .= "} else {";

			$element .= "alert('You are not yet select items');";

			$element .= "return false;";

			$element .= "}";

			$element .= "});";

			return $element;

		} else {

			return false;
		}

	}

	public function ajax_element_delete($selector = '',$selector_select = '',$controller = ''){

		if(isset($selector) && isset($selector_select) && isset($controller)){

			$element  = "$('".$selector."').on('click',function(){";

			$element .= "var checked_selected = $('".$selector_select."');";

			$element .= "var selected = [];";

			$element .= "var count_checked_length = 0;";

			$element .= "$(checked_selected).each(function(i,e){";

			$element .= "var checked = $(this).prop('checked');";

			$element .= "var checked_length = $(checked).length;";

			$element .= "count_checked_length+=checked_length;";

			$element .= "if(checked){";

			$element .= "selected.push($(this).val());";

			$element .= "}";

			$element .= "});";

			$element .= "if(count_checked_length > 0){";

			$element .= "if(confirm('Are you sure to update your item?')){";

			$element .= "$.ajax({";

			$element .= "url: '".base_url().$controller."',";
			$element .= "type: 'POST',";
			$element .= "dataType: 'json',";
			$element .= "data: { id: selected },";
			$element .= "beforeSend: function(){";

			$element .= "$('.overlay').show();";

			$element .= "},";
			$element .= "success: function(result){";

			$element .= "alert('Delete Success, Redirecting..');";

			$element .= "$('.overlay').hide().fadeOut('fast');";

			$element .= "setTimeout(function(){ ";

			$element .= "window.location.href = '".base_url()."' + result;";

			$element .= "}, 500);";

			$element .= "},";
			$element .= "fail: function(){";

			$element .= "$('.overlay').hide().fadeOut('fast');";

			$element .= "alert('Something Wrong, Please Try Again');";

			$element .= "}";

			$element .= "})";

			$element .= "} else {";

			$element .= "return false;";

			$element .= "	}";

			$element .= "} else {";

			$element .= "alert('You are not yet select items');";

			$element .= "return false;";

			$element .= "}";

			$element .= "});";

			return $element;

		} else {

			return false;
		}

	}

	public function datatables_data($query,$data = array()){
		//$draw = intval($this->input->get("draw"));
		//$start = intval($this->input->get("start"));
		//$length = intval($this->input->get("length"));

		//$query = $this->db->get("items");

/*
		foreach($query->result() as $r) {
			$data[] = array(
				$r->id,
				$r->title,
				$r->description
				);
			}*/

			$result = array(
			//"draw" => $draw,
				"recordsTotal" => $query->num_rows(),
				"recordsFiltered" => $query->num_rows(),
				"data" => $data
				);

			return $result;
		}

		public function datatables_init($turn_on = FALSE,$selector = ''){

			if($turn_on == TRUE && isset($selector)){

				$element = "var non_drag_table = $('".$selector."').DataTable({";

				$element .= "responsive: true,";

				$element .= "scrollCollapse: true,";

				$element .= "scrollY: 500,";

				$element .= "scrollX: '100%',";

				$element .= "paging: false";

				$element .= "});";

				return $element;

			} else {

				return false;

			}

		}

		public function datatables_ajax_data($turn_on = FALSE,$selector = '',$controller = '',$plugin_download = ''){

			if($turn_on == TRUE && isset($selector)){

				$element = "var ajax_data_table = $('#".$selector."').DataTable({";

/*				$element .= "responsive: true,";

				$element .= "scrollX: '100%',";*/

				if(!empty($plugin_download)){
				$element .=	"dom: 'Bfrtip',";
				$element .= "buttons: [ { extend: '".$plugin_download."' ,text: 'Download XLS' }],";
				}

				$element .= "ajax: {";

				$element .= "url: '".base_url().$controller."',";

				$element .= "type : 'GET'";

				$element .= "}";

				$element .= "});";

				return $element;

			} else {

				return false;

			}

		}

		public function datatables_roworder($turn_on = FALSE,$selector = '',$controller = ''){

			if($turn_on == TRUE && isset($selector) && isset($controller)){

				$element = "var drag_table = $('#".$selector."').DataTable({";

				$element .= "rowReorder: true,";

				$element .= "responsive: true,";

				$element .= "scrollCollapse: true,";

				$element .= "scrollY: 450,";

				$element .= "scrollX: '100%',";

				$element .= "paging: false,";

				$element .= "'sDom': 'rt'";

				$element .= "});";

				$element .= "drag_table.on( 'row-reorder', function ( e, diff, edit ) {";

				$element .= "setTimeout(function() {";

				$element .= "var id = [];";

				$element .= "var sort = [];";

				$element .= "$('".$selector."').find('tbody').find('tr').each(function(i,r){";

				$element .= "id.push($(r).attr('id'));";

				$element .= "sort.push(i);";

				$element .= "});";

				$element .= "if(diff.length > 0){";

				$element .= "$.ajax({";

				$element .= "url: '".base_url().$controller."',";

				$element .= "type: 'POST',";

				$element .= "dataType: 'json',";

				$element .= "data: { id: id, sort: sort },";

				$element .= "beforeSend: function(data){";

				$element .= "$('.overlay').show();";

				$element .= "	},";

				$element .= "success: function(result){";

				$element .= "var data = $.parseJSON(result);";

				$element .= "alert('Update Sort Success');";

				$element .= "if(data == true){";

				$element .= "$('.overlay').hide().fadeOut('fast');";

				$element .= "}";

				$element .= "},";

				$element .= "fail: function(){";

				$element .= "alert('Something wrong, please refresh your browser');";

				$element .= "$('.overlay').hide().fadeOut('fast');";

				$element .= "}";

				$element .= "});";

				$element .= "}";

				$element .= "}, 10);";

				$element .= " });";

				return $element;

			} else {

				return false;

			}

		}

		public function required_message_only($key,$message){

			return $message;

		}

		public function alert_bootstrap($message = ''){

			if(isset($message)){

				$element  = '<div id="alert-notifications" style="padding-right: 0;" class="modal fade" data-keyboard="false" data-backdrop="static" role="dialog">';

				$element .= '<div class="modal-dialog modal-sm">';

				$element .= '<div class="modal-content">';

				$element .= '<div class="modal-header">';

				$element .= '<h4 class="modal-title"><i class="fa fa-info-circle"></i> Notifications</h4>';

				$element .= '</div>';

				$element .= '<div class="modal-body">';

				$element .= $message;

				$element .= '</div>';

				$element .= '<div class="modal-footer">';

				$element .= '<button type="button" class="close btn btn-default">OK</button>';

				$element .= '</div>';

				$element .= '</div>';

				$element .= '</div>';

				$element .= '</div>';

				return $element;

			} else {

				return false;

			}

		}


	}